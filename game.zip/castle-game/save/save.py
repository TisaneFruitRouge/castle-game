import json

from utils import bcolors

from Character.characters import Trader, Thief, Orc
from Locations.locations import Plain, Town, Bar, Shop, BlackForest, Castle
from Items.items import Weapon, Protection, Potion


# https://stackoverflow.com/questions/12309269/how-do-i-write-json-data-to-a-file
def save_data(character, location):
    
    with open('save/character.json', 'w') as characters_save:
        char_dict = dict(character.__dict__)
        char_dict["inventory"] = []
        for item in character.inventory:
            char_dict["inventory"].append(dict(item.__dict__))
        json.dump(char_dict, characters_save, indent=4)

    with open('save/location.json', 'w') as location_save:
        json.dump(location.name, location_save, indent=4)

def read_character():
    with open('save/character.json') as character_data:
        data = json.load(character_data)

        items_data = data["inventory"]
        items = []
        
        for item in items_data:

            if (item["color"] == bcolors.DAMAGE_COLOR):
                items.append(Weapon(item["name"],item["price"],item["attack_damage"]))
            elif (item["color"] == bcolors.HEALTH_COLOR):
                items.append(Protection(item["name"],item["price"],item["health_boost"]))
            elif (item["color"] == bcolors.POTION_COLOR):
                items.append(Potion(item["price"],item["amount"]))

        data["inventory"] = items 

        if (data["name"] == "Thief"):   
            character = Thief(data["max_health"]+20, data["base_damage"]-15, data["coins"]-20)
        elif (data["name"] == "Trader"):
            character = Trader(data["max_health"], data["base_damage"], data["coins"])
        elif (data["name"] == "Orc"):
            character = Orc(data["max_health"]-20, data["base_damage"]-10, data["coins"])

        character.inventory = data["inventory"]

        character.unlocked_door = data["unlocked_door"]
        character.dragon_defeated = data["dragon_defeated"]

        return character

def read_location():
    location_dict = {"Plain": Plain,
                     "Town": Town,
                     "Bar": Bar,
                     "Shop": Shop,
                     "BlackForest": BlackForest,
                     "Castle": Castle}

    with open('save/location.json') as character_data:
        data = json.load(character_data)
        return location_dict[data]()